package com.firmino.hexagonal.application.core.usecase;

import com.firmino.hexagonal.application.core.domain.Customer;
import com.firmino.hexagonal.application.ports.in.FindCustomerByIdInputPort;
import com.firmino.hexagonal.application.ports.out.FindCustomerByIdOutputPort;

public class FindCustomerByIdUseCase implements FindCustomerByIdInputPort {

    private final FindCustomerByIdOutputPort findCostumerByIdOutputPort;

    public FindCustomerByIdUseCase(FindCustomerByIdOutputPort findCostumerByIdOutputPort) {
        this.findCostumerByIdOutputPort = findCostumerByIdOutputPort;
    }

    @Override
    public Customer findById(String id){
        var customer = findCostumerByIdOutputPort.findById(id);
        return customer.orElseThrow(() -> new RuntimeException("Customer not found"));
    }

}
