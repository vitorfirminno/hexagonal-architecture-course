package com.firmino.hexagonal.application.core.usecase;

import com.firmino.hexagonal.application.core.domain.Customer;
import com.firmino.hexagonal.application.ports.in.InsertCustomerInputPort;
import com.firmino.hexagonal.application.ports.out.FindAddressByZipCodeOutputPort;
import com.firmino.hexagonal.application.ports.out.InsertCustomerOutputPort;

public class InsertCustomerUseCase implements InsertCustomerInputPort {

    private final FindAddressByZipCodeOutputPort findAddressByZipCodeOutputPort;

    private final InsertCustomerOutputPort insertCostumerOutputPort;

    public InsertCustomerUseCase(FindAddressByZipCodeOutputPort findAddressByZipCodeOutputPort, InsertCustomerOutputPort insertCostumerOutputPort) {
        this.findAddressByZipCodeOutputPort = findAddressByZipCodeOutputPort;
        this.insertCostumerOutputPort = insertCostumerOutputPort;
    }

    @Override
    public void insert(Customer costumer, String zipCode){
        var address = findAddressByZipCodeOutputPort.find(zipCode);
        costumer.setAddress(address);
        insertCostumerOutputPort.insert(costumer);
    }

}
