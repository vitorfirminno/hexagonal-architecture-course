package com.firmino.hexagonal.config;


import com.firmino.hexagonal.application.core.usecase.InsertCustomerUseCase;
import com.firmino.hexagonal.application.ports.in.InsertCustomerInputPort;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class InsertCustomerConfiguration {

    @Bean
    public InsertCustomerInputPort insertCustomer(

    ){
        return new InsertCustomerUseCase();
    }

}
