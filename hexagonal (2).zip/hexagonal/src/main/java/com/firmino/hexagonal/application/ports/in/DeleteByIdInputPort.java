package com.firmino.hexagonal.application.ports.in;

public interface DeleteByIdInputPort {

    void delete(String id);

}
