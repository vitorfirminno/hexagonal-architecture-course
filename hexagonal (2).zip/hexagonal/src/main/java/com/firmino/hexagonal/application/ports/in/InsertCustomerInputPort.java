package com.firmino.hexagonal.application.ports.in;

import com.firmino.hexagonal.application.core.domain.Customer;

public interface InsertCustomerInputPort {

    void insert(Customer customer, String zipCode);

}
