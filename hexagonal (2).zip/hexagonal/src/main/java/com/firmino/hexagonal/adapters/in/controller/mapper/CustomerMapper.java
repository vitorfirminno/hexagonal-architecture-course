package com.firmino.hexagonal.adapters.in.controller.mapper;

import com.firmino.hexagonal.adapters.in.controller.request.CustomerRequest;
import com.firmino.hexagonal.adapters.in.controller.response.CustomerResponse;
import com.firmino.hexagonal.application.core.domain.Customer;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CustomerMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "address", ignore = true)
    //@Mapping(target = "isValid", ignore = true)
    Customer toCustomer(CustomerRequest customerRequest);

    CustomerResponse toCustomerResponse(Customer customer);

}
